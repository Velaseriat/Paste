// _explosive_bolt.csc
// Sets up clientside behavior for the explosive bolt

main()
{
	level._effect["crossbow_enemy_light"] = load_crossbow_blink_fx(
		"weapon/crossbow/fx_trail_crossbow_blink_red",
		"weapon/crossbow/fx_trail_crossbow_blink_red_os"
	);
	level._effect["crossbow_friendly_light"] = load_crossbow_blink_fx(
		"weapon/crossbow/fx_trail_crossbow_blink_grn",
		"weapon/crossbow/fx_trail_crossbow_blink_grn_os"
	);
	//SetDvarFloat("snd_crossbow_bolt_timer_interval", 0.4); 
	//SetDvarFloat("snd_crossbow_bolt_timer_divisor", 1.4); 

	PrintLn( "crossbow_enemy_light :" + level._effect["crossbow_enemy_light"] );
	PrintLn( "crossbow_friendly_light :" + level._effect["crossbow_friendly_light"] );
}

load_crossbow_blink_fx( primary_fx_path, fallback_fx_path )
{
	fx = loadfx( primary_fx_path );
	if( !IsDefined( fx ) )
	{
		fx = loadfx( fallback_fx_path );
	}
	return fx;
}


spawned( localClientNum, play_sound, bool_monkey_bolt ) // self == the crossbow bolt
{
	if( !IsDefined( localClientNum ) )
	{
		// SP/hosted zombie can dispatch without an explicit client index.
		localClientNum = 0;
	}

	PrintLn("explosive bolt spawned");
	player = GetLocalPlayer( localClientNum );
	enemy = false;
	self.fxTagName = "tag_origin";
	
	if( !IsDefined( bool_monkey_bolt ) ) // WWilliams (8/14/10): new condition for the upgraded zombie crossbow. 
	{
		bool_monkey_bolt = false; // WWilliams (8/14/10): set the value to false to keep old scripts from breaking
	}

	if ( self.team != player.team )
	{
		enemy = true;
	}

	if ( enemy && bool_monkey_bolt == false )
	{
		if( IsDefined( level._effect["crossbow_enemy_light"] ) )
		{
			self thread loop_local_sound( localClientNum, "wpn_crossbow_alert", 0.3, level._effect["crossbow_enemy_light"] );
		}
		else
		{
			// Keep audio feedback even if the blink FX fails to load.
			self thread loop_local_sound_no_fx( localClientNum, "wpn_crossbow_alert", 0.3 );
		}
	}
	else if( bool_monkey_bolt == true ) 
	{
		// WWilliams (8/14/10): this should make it so all zombie players see a red light for the upgraded zombie crossbow
		if( IsDefined( level._effect["crossbow_enemy_light"] ) )
		{
			self thread loop_local_sound( localClientNum, "wpn_crossbow_alert", 0.3, level._effect["crossbow_enemy_light"] );
		}
		else
		{
			self thread loop_local_sound_no_fx( localClientNum, "wpn_crossbow_alert", 0.3 );
		}
	}
	else
	{
		if( IsDefined( level._effect["crossbow_friendly_light"] ) )
		{
			self thread loop_local_sound( localClientNum, "wpn_crossbow_alert", 0.3, level._effect["crossbow_friendly_light"] );
		}
		else
		{
			self thread loop_local_sound_no_fx( localClientNum, "wpn_crossbow_alert", 0.3 );
		}
	}
}

loop_local_sound( localClientNum, alias, interval, fx ) // self == the crossbow bolt
{
	self endon( "entityshutdown" );
	
	if( !IsDefined( localClientNum ) )
	{
		localClientNum = 0;
	}
	
	if( !IsDefined( fx ) )
	{
		return;
	}

	// also playing the blinking light fx with the sound

	while(1)
	{
		self PlaySound( localClientNum, alias );
		PlayFXOnTag( localClientNum, fx, self, self.fxTagName );

		wait(interval);
		interval = (interval / 1.2);

		if (interval < .1)
		{
			interval = .1;
		}	
	}
}

loop_local_sound_no_fx( localClientNum, alias, interval ) // self == the crossbow bolt
{
	self endon( "entityshutdown" );
	
	if( !IsDefined( localClientNum ) )
	{
		localClientNum = 0;
	}
	
	while(1)
	{
		self PlaySound( localClientNum, alias );
		wait( interval );
		interval = (interval / 1.2);
		if (interval < .1)
		{
			interval = .1;
		}
	}
}
