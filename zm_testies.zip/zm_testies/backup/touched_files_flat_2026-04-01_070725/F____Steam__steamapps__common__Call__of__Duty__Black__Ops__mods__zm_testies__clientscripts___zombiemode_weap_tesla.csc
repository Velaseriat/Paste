#include clientscripts\_utility; 
#include clientscripts\_fx;
#include clientscripts\_music;

init()
{
	if ( GetDvar( #"createfx" ) == "on" )
	{
		return;
	}

	if ( !clientscripts\_zombiemode_weapons::is_weapon_included( "tesla_gun_zm" ) && !(isdefined( level.uses_tesla_powerup ) && level.uses_tesla_powerup) )
	{
		return;
	}

	level._effect["tesla_viewmodel_rail"] = load_tesla_fx_with_fallback( "maps/zombie/fx_zombie_tesla_rail_view", "weapon/muzzleflashes/fx_tesla_view" );
	level._effect["tesla_viewmodel_tube"] = load_tesla_fx_with_fallback( "maps/zombie/fx_zombie_tesla_tube_view", "weapon/muzzleflashes/fx_tesla_view" );
	level._effect["tesla_viewmodel_tube2"] = load_tesla_fx_with_fallback( "maps/zombie/fx_zombie_tesla_tube_view2", "weapon/muzzleflashes/fx_tesla_view" );
	level._effect["tesla_viewmodel_tube3"] = load_tesla_fx_with_fallback( "maps/zombie/fx_zombie_tesla_tube_view3", "weapon/muzzleflashes/fx_tesla_view" );

	level._effect["tesla_viewmodel_rail_upgraded"]	= load_tesla_fx_with_fallback( "maps/zombie/fx_zombie_tesla_rail_view_ug", "weapon/muzzleflashes/fx_tesla_ug_view" );
	level._effect["tesla_viewmodel_tube_upgraded"]	= load_tesla_fx_with_fallback( "maps/zombie/fx_zombie_tesla_tube_view_ug", "weapon/muzzleflashes/fx_tesla_ug_view" );
	level._effect["tesla_viewmodel_tube2_upgraded"]	= load_tesla_fx_with_fallback( "maps/zombie/fx_zombie_tesla_tube_view2_ug", "weapon/muzzleflashes/fx_tesla_ug_view" );
	level._effect["tesla_viewmodel_tube3_upgraded"]	= load_tesla_fx_with_fallback( "maps/zombie/fx_zombie_tesla_tube_view3_ug", "weapon/muzzleflashes/fx_tesla_ug_view" );
	
	PrintLn( "TESLA CSC: init" );
	level thread player_init();
	level thread tesla_notetrack_think();
}

load_tesla_fx_with_fallback( primary_fx_path, fallback_fx_path )
{
	fx = loadfx( primary_fx_path );
	if( !IsDefined( fx ) )
	{
		fx = loadfx( fallback_fx_path );
		PrintLn( "TESLA CSC: fallback fx " + primary_fx_path + " -> " + fallback_fx_path );
	}
	return fx;
}

player_init()
{
	waitforclient( 0 );
	level.tesla_play_fx = [];
	level.tesla_play_rail = true;
	
	players = GetLocalPlayers();
	for( i = 0; i < players.size; i++ )
	{
		level.tesla_play_fx[i] = true;
		players[i] thread tesla_fx_rail( i );
		players[i] thread tesla_fx_tube( i );
		players[i] thread tesla_happy( i );
	}
}

tesla_fx_rail( localclientnum )
{
	self endon( "disconnect" );
	
	for( ;; )
	{
		realwait( RandomFloatRange( 1.5, 2.5 ) );

		currentweapon = GetCurrentWeapon( localclientnum ); 
		if ( currentweapon == "tesla_gun_zm" || currentweapon == "tesla_gun_upgraded_zm" )
		{
			level.tesla_play_fx[localclientnum] = true;
		}
		
		if ( !level.tesla_play_fx[localclientnum] )
		{
			continue;
		}
		if ( !level.tesla_play_rail )
		{			
			continue;
		}

		if ( currentweapon != "tesla_gun_zm" && currentweapon != "tesla_gun_upgraded_zm" )
		{
			continue;
		}

		if ( IsADS( localclientnum ) || IsThrowingGrenade( localclientnum ) || IsMeleeing( localclientnum ) || IsOnTurret( localclientnum ) )
		{
			continue;
		}
		
		if ( GetWeaponAmmoClip( localclientnum, currentweapon ) <= 0 )
		{
			continue;
		}
		
		fx = level._effect["tesla_viewmodel_rail"];
		
		if ( currentweapon == "tesla_gun_upgraded_zm" )
		{
			fx = level._effect["tesla_viewmodel_rail_upgraded"];
		}
		
		play_tesla_fx_on_all_possible_tags( localclientnum, fx );
		playsound(localclientnum,"wpn_tesla_effects", (0,0,0));
	}
}

tesla_fx_tube( localclientnum )
{
	self endon( "disconnect" );
		
	for( ;; )
	{
		realwait( 0.1 );

		currentweapon = GetCurrentWeapon( localclientnum ); 
		if ( currentweapon == "tesla_gun_zm" || currentweapon == "tesla_gun_upgraded_zm" )
		{
			level.tesla_play_fx[localclientnum] = true;
		}
		
		if ( !level.tesla_play_fx[localclientnum] )
		{
			continue;
		}

		if ( currentweapon != "tesla_gun_zm" && currentweapon != "tesla_gun_upgraded_zm" )
		{
			continue;
		}

		if ( IsThrowingGrenade( localclientnum ) || IsMeleeing( localclientnum ) || IsOnTurret( localclientnum ) )
		{
			continue;
		}
		
		ammo = GetWeaponAmmoClip( localclientnum, currentweapon );
				
		if ( ammo <= 0 )
		{
			continue;
		}
		
		fx = level._effect["tesla_viewmodel_tube"];
		
		if ( currentweapon == "tesla_gun_upgraded_zm" )
		{
			if ( ammo == 3 || ammo == 4 )
			{
				fx = level._effect["tesla_viewmodel_tube2_upgraded"];
			}
			else if ( ammo == 1 || ammo == 2 )
			{
				fx = level._effect["tesla_viewmodel_tube3_upgraded"];
			}
			else
			{
				fx = level._effect["tesla_viewmodel_tube_upgraded"];
			}
		}
		else
		{
			if ( ammo == 1 )
			{
				fx = level._effect["tesla_viewmodel_tube3"];
			}
			else if ( ammo == 2 )
			{
				fx = level._effect["tesla_viewmodel_tube2"];
			}
			else
			{
				fx = level._effect["tesla_viewmodel_tube"];
			}
		}
		
		play_tesla_fx_on_all_possible_tags( localclientnum, fx );
	}
}

play_tesla_fx_on_all_possible_tags( localclientnum, fx )
{
	PlayViewmodelFx( localclientnum, fx, "tag_brass" );
}

tesla_notetrack_think()
{
	for ( ;; )
	{
		level waittill( "notetrack", localclientnum, note );
		
		switch( note )
		{
		case "sndnt#wpn_tesla_switch_flip_off":
		case "tesla_switch_flip_off":
		case "sndnt#wpn_tesla_first_raise_start":
			level.tesla_play_fx[localclientnum] = false;			
		break;	
			
		case "sndnt#wpn_tesla_switch_flip_on":
		case "tesla_switch_flip_on":
		case "sndnt#wpn_tesla_pullout_start":
		case "tesla_to_idle":
		case "tesla_idle_start":
			level.tesla_play_fx[localclientnum] = true;			
		break;			
		}
	}
}

tesla_happy( localclientnum )
{
	for(;;)
	{
		level waittill ("TGH");
		currentweapon = GetCurrentWeapon( localclientnum ); 
		if ( currentweapon == "tesla_gun_zm" || currentweapon == "tesla_gun_upgraded_zm" )
		{
			playsound(localclientnum,"wpn_tesla_happy", (0,0,0));
			level.tesla_play_rail = false;
			realwait(2);
			level.tesla_play_rail = true;
		}
	}
}